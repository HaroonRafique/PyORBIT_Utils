from tunespread import *


q = 1


# deltap = 5.5e-4
# emit_x = 7e-6
# emit_y = 2.7e-6
# n_part = 2e11
# blength = 100 # ns 
# Ekin = 1.4

# 0.85 eVs
deltap = 0.9e-3
emit_x = 1e-6
emit_y = 1e-6
n_part = 7.5e11
blength = 145 # ns 
Ekin = 1.4

# 1.45 eVs
deltap = 1.4e-3
emit_x = 1e-6
emit_y = 1e-6
n_part = 7.5e11
blength = 155 # ns 
Ekin = 1.4

# LIU
# deltap = 1.1e-3
# emit_x = 1.43e-6
# emit_y = 1.43e-6
# n_part = 16.25e11
# blength = 135 # ns 
# Ekin = 2.

twissfile = ['PS-inj2GeV-data.tfs', 'PS-inj2GeV-s.tfs']
params = {'n_part': n_part, 'emit_norm_x': emit_x, 'emit_norm_y': emit_y, 'Ekin': Ekin,
          'deltap': deltap, 'n_charges_per_part': q, 'lshape':1., 'bunch_length': blength, 'coasting': False} 
data, inputs = ext.get_inputs(twissfile, params, False, False)
dQ = calc_tune_spread(data, inputs)
print inputs
ext.print_verbose_output(inputs, data, dQ[0], dQ[1])
print "dQx = %2.3f, dQy = %2.3f"%(dQ[0], dQ[1])







# from tune_diagram import resonance_lines
# from matplotlib.collections import PatchCollection
# from matplotlib.patches import Circle, Wedge, Polygon
# import matplotlib.pylab as plt

# WP = {'H': 20.13, 'V': 20.18}
# WP = {'H': 20.36, 'V': 20.15}

# resonances = resonance_lines((19.9,20.5),(19.9,20.5),(1,2,3),6)
# fig, ax = plt.subplots(1, figsize=(4.5,4.5))
# fig = resonances.plot_resonance(fig)
# ax = fig.get_axes()[0]
# ax.plot(WP['H'], WP['V'], 'g.', markersize=12)
# ax.set_aspect('equal')

# Qx0 = WP['H']-dQ[0]
# Qy0 = WP['V']-dQ[1]
# radius = 0.5 * np.sqrt(dQ[0]**2 + dQ[1]**2)
# angle  = np.arctan(dQ[1]/dQ[0])
# angle_offset = 14 * np.pi / 180

# poly = ([Qx0, Qy0], [Qx0+radius*np.cos(angle-angle_offset), Qy0+radius*np.sin(angle-angle_offset)],
# 		[WP['H'], WP['V']], [Qx0+radius*np.cos(angle+angle_offset), Qy0+radius*np.sin(angle+angle_offset)])
# patch = PatchCollection([Polygon(poly, True)], color='g', alpha=0.3)
# ax.add_collection(patch)
# plt.show()
# # plt.savefig('tunediagram.pdf', bbox_inches='tight')
